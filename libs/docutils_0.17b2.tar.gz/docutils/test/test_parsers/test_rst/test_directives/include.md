# Title 1

*emphasis* and _also emphasis_

No whitespace required around a[phrase reference].

[phrase reference]: /uri
